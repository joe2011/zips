import xbmc
import xbmcgui
import xbmcaddon

ADDON = xbmcaddon.Addon(id="service.showproviders")
MONITOR = xbmc.Monitor()

def get_providers():
    providers = []
    for i in range(1, 11):
        provider = xbmc.getInfoLabel(f"Window(Home).Property(TMDbHelper.ListItem.Provider.{i}.Name)")
        if provider:
            providers.append(provider)
    return " • ".join(providers) if providers else None

def show_notification(message):
    xbmcgui.Dialog().notification("Providers disponibili", message, xbmcgui.NOTIFICATION_INFO, 5000)

def main():
    last_focused_item = ""

    while not MONITOR.abortRequested():  # Il servizio rimane in esecuzione finché Kodi non viene chiuso
        xbmc.sleep(1000)  # Controlla ogni secondo

        # Ottiene il titolo dell'elemento selezionato
        focused_item = xbmc.getInfoLabel("ListItem.Title")

        # Se l'elemento selezionato cambia, mostra la notifica con i providers
        if focused_item and focused_item != last_focused_item:
            last_focused_item = focused_item
            providers = get_providers()
            if providers:
                show_notification(providers)

if __name__ == "__main__":
    main()